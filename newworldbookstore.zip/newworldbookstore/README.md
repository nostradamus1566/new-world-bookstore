##This is a Bookstore front end website project

##It is not completed yet. So far I have only done the first page.

The menubar is much the way I want it to appear, but there are no web pages linked to the items in the dropdown list.

##The Contact Form page is not done.

##I got ideas for the carousel from the official bootstrap4 website.

##The text describing the 'Modern Ireland' text book came from the publisher's website.




